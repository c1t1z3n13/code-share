nfd-status
==========

SYNOPSIS
--------
| nfd-status

DESCRIPTION
-----------
**nfd-status** is an alias of **nfdc status report**, which prints a comprehensive report of NFD status.

SEE ALSO
--------
nfdc-status(1)
